export type EventType =
  | "Birthday"
  | "Anniversary"
  | "Festival"
  | "Congratulations";

export interface Event {
  id?: number;
  name: string;
  date: string; // YYYY-MM-DD
  type: string;
  message: string;
  templateId?: number;
  reminderDays: number;
  reminderHour: number; // used for both notifications
  reminderMinute: number;
  notificationIds?: string[];
}
