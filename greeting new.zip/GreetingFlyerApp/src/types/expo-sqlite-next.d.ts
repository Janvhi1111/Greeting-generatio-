declare module 'expo-sqlite/next' {
  import * as SQLite from 'expo-sqlite';
  export * from 'expo-sqlite';
}
