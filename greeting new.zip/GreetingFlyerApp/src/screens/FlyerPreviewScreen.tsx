import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  ActivityIndicator,
  Alert,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import FlyerTemplate from "../components/FlyerTemplate";
import {
  fetchEvents,
  deleteEventWithNotifications,
} from "../services/eventService";
import { Event } from "../types/Event";

import ViewShot, { captureRef } from "react-native-view-shot";
import * as FileSystem from "expo-file-system";
import * as MediaLibrary from "expo-media-library";
import * as Sharing from "expo-sharing";
import { Share } from "react-native";

type Props = NativeStackScreenProps<RootStackParamList, "FlyerPreview">;

export default function FlyerPreviewScreen({ route, navigation }: Props) {
  const { eventId } = route.params;
  const [event, setEvent] = useState<Event | null>(null);
  const [permissionResponse, requestPermission] = MediaLibrary.usePermissions();
  const viewShotRef = useRef<View>(null);

  useEffect(() => {
    const load = async () => {
      const events = await fetchEvents();
      const e = events.find((ev) => ev.id === eventId);
      setEvent(e ?? null);
    };
    load();
  }, [eventId]);

  const exportFlyer = async () => {
    if (!permissionResponse?.granted) {
      const res = await requestPermission();
      if (!res.granted) {
        Alert.alert("Permission needed", "Storage permission is required to save flyer.");
        return;
      }
    }

    try {
      const uri = await captureRef(viewShotRef, {
        format: "png",
        quality: 1,
      });

      const asset = await MediaLibrary.createAssetAsync(uri);
      await MediaLibrary.createAlbumAsync("GreetingFlyers", asset, false);
      Alert.alert("Saved", "Flyer saved to gallery");
    } catch (err) {
      console.error("Export error", err);
      Alert.alert("Error", "Failed to export flyer");
    }
  };

  const shareFlyer = async () => {
    try {
      const uri = await captureRef(viewShotRef, {
        format: "png",
        quality: 1,
      });

      const fileUri = FileSystem.cacheDirectory + "flyer.png";
      await FileSystem.copyAsync({ from: uri, to: fileUri });

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(fileUri, {
          mimeType: "image/png",
          dialogTitle: "Share your greeting flyer",
        });
      } else {
        await Share.share({
          message: "Here is your flyer!",
          url: fileUri,
        });
      }
    } catch (error) {
      console.error("Share failed", error);
      Alert.alert("Error", "Could not share flyer");
    }
  };

  const handleDelete = () => {
    if (!event) return;

    Alert.alert("Delete Event", "Are you sure you want to delete this flyer event?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          await deleteEventWithNotifications(event);
          Alert.alert("Deleted", "Event has been removed.");
          navigation.goBack();
        },
      },
    ]);
  };

  if (!event) {
    return <ActivityIndicator style={{ marginTop: 40 }} />;
  }

  return (
    <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.header}>Flyer Preview</Text>

      <ViewShot
        ref={viewShotRef}
        style={styles.flyerContainer}
        options={{ format: "png", quality: 1 }}
      >
        <FlyerTemplate
          name={event.name}
          type={event.type}
          date={event.date}
          message={event.message}
        />
      </ViewShot>

      <View style={styles.buttonGroup}>
        <ActionButton title="Save to Gallery" onPress={exportFlyer} />
        <ActionButton title="Share Flyer" onPress={shareFlyer} />
        <ActionButton
          title="Edit Event"
          onPress={() => navigation.navigate("EventForm", { eventId: event.id! })}
        />
        <ActionButton title="Delete Event" color="#dc3545" onPress={handleDelete} />
        <ActionButton title="Back" color="#6c757d" onPress={() => navigation.goBack()} />
      </View>
    </ScrollView>
  );
}

function ActionButton({
  title,
  onPress,
  color = "#007bff",
}: {
  title: string;
  onPress: () => void;
  color?: string;
}) {
  return (
    <TouchableOpacity style={[styles.button, { backgroundColor: color }]} onPress={onPress}>
      <Text style={styles.buttonText}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    gap: 20,
    alignItems: "center",
    backgroundColor: "#f9f9f9",
    flexGrow: 1,
  },
  header: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 12,
  },
  flyerContainer: {
    width: 300,
    height: 400,
    backgroundColor: "#ffffff",
    borderRadius: 12,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
  },
  buttonGroup: {
    width: "100%",
    gap: 12,
    marginTop: 20,
  },
  button: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: {
    color: "#ffffff",
    fontSize: 15,
    fontWeight: "600",
  },
});
