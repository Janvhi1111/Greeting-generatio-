import React, { useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  Platform,
  Alert,
  TouchableOpacity,
  StyleSheet,
  Text,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';
import { TextInput } from 'react-native-paper';
import { insertEvent, updateEvent, fetchEvents } from '../services/eventService';
import { scheduleReminderNotification } from '../services/notificationService';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { Event, EventType } from '../types/Event';

type Props = NativeStackScreenProps<RootStackParamList, 'EventForm'>;

export default function EventFormScreen({ navigation, route }: Props) {
  const editingEventId = route.params?.eventId;

  const [name, setName] = useState('');
  const [eventDate, setEventDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [type, setType] = useState<EventType>('Birthday');
  const [message, setMessage] = useState('');
  const [reminderDays, setReminderDays] = useState('1');
  const [reminderTime, setReminderTime] = useState(new Date());
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);

  useEffect(() => {
    if (editingEventId) {
      fetchEvents().then((events) => {
        const target = events.find((e) => e.id === editingEventId);
        if (target) {
          setEditingEvent(target);
          setName(target.name);
          setEventDate(new Date(target.date));
          setType(target.type as EventType);
          setMessage(target.message);
          setReminderDays(String(target.reminderDays));
          const time = new Date();
          time.setHours(target.reminderHour ?? 9);
          time.setMinutes(target.reminderMinute ?? 0);
          setReminderTime(time);
        }
      });
    }
  }, [editingEventId]);

  const saveEvent = async () => {
    if (!name || !message || !reminderDays) {
      Alert.alert('Validation', 'Please fill in all required fields.');
      return;
    }

    const eventPayload: Event = {
      id: editingEventId ?? undefined,
      name,
      date: eventDate.toISOString().split('T')[0],
      type,
      message,
      reminderDays: parseInt(reminderDays, 10),
      templateId: 0,
      reminderHour: reminderTime.getHours(),
      reminderMinute: reminderTime.getMinutes(),
      notificationIds: editingEvent?.notificationIds ?? [],
    };

    try {
      if (editingEvent) {
        await updateEvent(eventPayload);
      } else {
        await insertEvent(eventPayload);
        await scheduleReminderNotification(eventPayload);
      }
      navigation.goBack();
    } catch (error) {
      console.error(error);
      Alert.alert('Error', 'Failed to save event');
    }
  };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.container}>
      <Text style={styles.header}>
        {editingEvent ? 'Edit Event' : 'Create New Event'}
      </Text>

      <TextInput
        label="Name"
        value={name}
        mode="outlined"
        onChangeText={setName}
        style={styles.input}
      />

      <Text style={styles.label}>Event Type</Text>
      <View style={styles.pickerWrapper}>
        <Picker
          selectedValue={type}
          onValueChange={(itemValue) => setType(itemValue as EventType)}
        >
          <Picker.Item label="Birthday" value="Birthday" />
          <Picker.Item label="Anniversary" value="Anniversary" />
          <Picker.Item label="Festival" value="Festival" />
          <Picker.Item label="Congratulations" value="Congratulations" />
        </Picker>
      </View>

      <Text style={styles.label}>Event Date</Text>
      <TouchableOpacity style={styles.selector} onPress={() => setShowDatePicker(true)}>
        <Text style={styles.selectorText}>{eventDate.toDateString()}</Text>
      </TouchableOpacity>
      {showDatePicker && (
        <DateTimePicker
          value={eventDate}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={(_, selectedDate) => {
            setShowDatePicker(false);
            if (selectedDate) setEventDate(selectedDate);
          }}
        />
      )}

      <TextInput
        label="Custom Message"
        value={message}
        mode="outlined"
        onChangeText={setMessage}
        style={[styles.input, { height: 100 }]}
        multiline
      />

      <TextInput
        label="Reminder Days Before"
        value={reminderDays}
        mode="outlined"
        onChangeText={setReminderDays}
        keyboardType="numeric"
        style={styles.input}
      />

      <Text style={styles.label}>Reminder Time</Text>
      <TouchableOpacity style={styles.selector} onPress={() => setShowTimePicker(true)}>
        <Text style={styles.selectorText}>
          {reminderTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </TouchableOpacity>
      {showTimePicker && (
        <DateTimePicker
          value={reminderTime}
          mode="time"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={(_, selectedTime) => {
            setShowTimePicker(false);
            if (selectedTime) setReminderTime(selectedTime);
          }}
        />
      )}

      <TouchableOpacity style={styles.saveButton} onPress={saveEvent}>
        <Text style={styles.saveText}>
          {editingEvent ? 'Update Event' : 'Save Event'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    backgroundColor: '#fefefe',
  },
  container: {
    padding: 20,
    paddingBottom: 80,
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 24,
    color: '#333',
    alignSelf: 'center',
  },
  input: {
    marginBottom: 16,
    backgroundColor: 'white',
  },
  label: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 10,
    color: '#555',
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#f5f5f5',
    overflow: 'hidden',
    marginBottom: 16,
  },
  selector: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#f0f0f0',
    marginBottom: 16,
  },
  selectorText: {
    fontSize: 16,
    color: '#333',
  },
  saveButton: {
    marginTop: 20,
    backgroundColor: '#007bff',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  saveText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
