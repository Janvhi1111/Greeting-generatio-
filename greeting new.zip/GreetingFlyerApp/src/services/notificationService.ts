import * as Notifications from 'expo-notifications';
import { Event } from '../types/Event';

export async function scheduleReminderNotification(event: Event): Promise<string[]> {
  const { reminderHour = 9, reminderMinute = 0 } = event;
  const now = new Date();

  console.log('\n---- Notification Scheduling ----');
  console.log('[Event]', event.name);
  console.log('[Type]', event.type);
  console.log('[Date]', event.date);
  console.log('[Reminder Time]', `${reminderHour}:${reminderMinute}`);
  console.log('[Now]', now.toString());

  const createTargetDate = (baseDate: string, offsetDays: number): Date => {
    const [year, month, day] = baseDate.split('-').map(Number);
    const target = new Date(year, month - 1, day); // Local time
    target.setDate(target.getDate() + offsetDays);
    target.setHours(reminderHour, reminderMinute, 0, 0);
    return target;
  };

  const notificationIds: string[] = [];
  const dayBefore = createTargetDate(event.date, -1);
  const onDay = createTargetDate(event.date, 0);

  const schedules = [
    {
      date: dayBefore,
      title: `Flyer ready: ${event.name}'s ${event.type} is tomorrow!`,
      body: `Flyer has been generated and is ready to share.`,
    },
    {
      date: onDay,
      title: `Today is ${event.name}'s ${event.type}!`,
      body: `Don't forget to share the flyer.`,
    },
  ];

  for (const { date, title, body } of schedules) {
    const secondsUntil = Math.floor((date.getTime() - now.getTime()) / 1000);

    console.log(`[Target] ${title}`, date.toString());
    console.log(`[Time diff] ${secondsUntil} seconds`);

    if (secondsUntil <= 0) {
      console.log(`[✗] Skipping ${title}: time already passed`);
      continue;
    }

    if (secondsUntil > 60 * 60 * 24 * 7) {
      console.log(`[✗] Skipping ${title}: more than 7 days in future`);
      continue;
    }

    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: { title, body },
        trigger: {
          type: 'timeInterval',
          seconds: secondsUntil,
          repeats: false,
        },
      });
      notificationIds.push(id);
      console.log(`[✓] Scheduled: ${title} at ${date.toLocaleString()} (ID: ${id})`);
    } catch (err) {
      console.error(`[✗] Failed to schedule ${title}`, err);
    }
  }

  console.log('---- Scheduling Complete ----\n');
  return notificationIds;
}
