import { openDatabaseAsync, SQLiteDatabase } from "expo-sqlite";
import * as Notifications from "expo-notifications";
import { Event } from "../types/Event";
import { scheduleReminderNotification } from "./notificationService";
import * as FileSystem from "expo-file-system";

let db: SQLiteDatabase;

// Initialize database only once
const initDBConnection = async () => {
  if (!db) {
    db = await openDatabaseAsync("events.db");
  }
};

export const initDB = async () => {
  await initDBConnection();
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      date TEXT NOT NULL,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      templateId INTEGER DEFAULT 0,
      reminderDays INTEGER DEFAULT 1,
      reminderHour INTEGER DEFAULT 9,
      reminderMinute INTEGER DEFAULT 0,
      notificationIds TEXT
    );
  `);
};

export const insertEvent = async (event: Event): Promise<void> => {
  await initDBConnection();

  const ids = await scheduleReminderNotification(event);

  await db.runAsync(
    `INSERT INTO events (name, date, type, message, templateId, reminderDays, reminderHour, reminderMinute, notificationIds)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      event.name,
      event.date,
      event.type,
      event.message,
      event.templateId ?? 0,
      event.reminderDays,
      event.reminderHour ?? 9,
      event.reminderMinute ?? 0,
      JSON.stringify(ids),
    ]
  );
};

export const fetchEvents = async (): Promise<Event[]> => {
  await initDBConnection();
  const result = await db.getAllAsync(`SELECT * FROM events ORDER BY date ASC`);

  return result.map(
    (row: any): Event => ({
      id: row.id,
      name: row.name,
      date: row.date,
      type: row.type,
      message: row.message,
      templateId: row.templateId,
      reminderDays: row.reminderDays,
      reminderHour: row.reminderHour,
      reminderMinute: row.reminderMinute,
      notificationIds: row.notificationIds
        ? JSON.parse(row.notificationIds)
        : [],
    })
  );
};

export const deleteEventWithNotifications = async (
  event: Event
): Promise<void> => {
  await initDBConnection();

  if (event.notificationIds && Array.isArray(event.notificationIds)) {
    for (const id of event.notificationIds) {
      try {
        await Notifications.cancelScheduledNotificationAsync(id);
        console.log(`[✓] Canceled notification ID: ${id}`);
      } catch (err) {
        console.warn(`[✗] Failed to cancel notification ID: ${id}`, err);
      }
    }
  }

  if (event.id !== undefined) {
    await db.runAsync(`DELETE FROM events WHERE id = ?`, [event.id]);
  } else {
    console.warn("Event deletion skipped: missing event.id");
  }
};

export const deleteDatabase = async () => {
  const dbPath = FileSystem.documentDirectory + "SQLite/events.db";
  try {
    await FileSystem.deleteAsync(dbPath, { idempotent: true });
    console.log("[✓] Database deleted:", dbPath);
  } catch (err) {
    console.error("[✗] Failed to delete DB", err);
  }
};

export const updateEvent = async (event: Event): Promise<void> => {
  await initDBConnection();
  if (!event.id) {
    return;
  }

  // Cancel old notifications if they exist
  if (event.notificationIds) {
    for (const id of event.notificationIds) {
      try {
        await Notifications.cancelScheduledNotificationAsync(id);
        console.log(`[✓] Canceled old notification ID: ${id}`);
      } catch (err) {
        console.warn(`[✗] Failed to cancel old notification ID: ${id}`);
      }
    }
  }

  // Reschedule new notifications
  const newNotificationIds = await scheduleReminderNotification(event);

  // Update the event in the database
  await db.runAsync(
    `UPDATE events SET
      name = ?,
      date = ?,
      type = ?,
      message = ?,
      templateId = ?,
      reminderDays = ?,
      reminderHour = ?,
      reminderMinute = ?,
      notificationIds = ?
     WHERE id = ?`,
    [
      event.name,
      event.date,
      event.type,
      event.message,
      event.templateId ?? 0,
      event.reminderDays,
      event.reminderHour ?? 9,
      event.reminderMinute ?? 0,
      JSON.stringify(newNotificationIds),
      event.id,
    ]
  );
};
