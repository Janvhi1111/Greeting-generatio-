import React, { useEffect, useState } from "react";
import { SvgXml } from "react-native-svg";
import { Asset } from "expo-asset";
import { readAsStringAsync } from "expo-file-system";

type Props = {
  name: string;
  date: string;
  type: string;
  message: string;
};

export default function FlyerTemplate({ name, date, type, message }: Props) {
  const [templateXml, setTemplateXml] = useState<string>("");

  useEffect(() => {
    const loadTemplate = async () => {
      const fileMap: Record<string, any> = {
        Birthday: require("../../assets/templates/birthday_templete.svg"),
        Anniversary: require("../../assets/templates/anniversary_templete.svg"),
        Festival: require("../../assets/templates/festival_templete.svg"),
        Congratulations: require("../../assets/templates/congrats_templete.svg"),
      };

      const assetModule = fileMap[type] || fileMap["Birthday"];

      const asset = Asset.fromModule(assetModule);
      await asset.downloadAsync(); // Ensure it's available

      const svgRaw = await readAsStringAsync(asset.localUri!);

      const rendered = svgRaw
        .replace("{{name}}", name)
        .replace("{{date}}", date)
        .replace("{{message}}", message);

      setTemplateXml(rendered);
    };

    loadTemplate();
  }, [name, date, type, message]);

  return templateXml ? (
    <SvgXml xml={templateXml} width="300" height="400" />
  ) : null;
}
