// src/navigation/AppNavigator.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import EventFormScreen from '../screens/EventFormScreen';
// import FlyerEditorScreen from '../screens/FlyerEditorScreen';
import FlyerPreviewScreen from '../screens/FlyerPreviewScreen';

export type RootStackParamList = {
  Home: undefined;
  EventForm: { eventId?: number } | undefined;
  FlyerEditor: { eventId: number };
  FlyerPreview: { eventId: number };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="EventForm" component={EventFormScreen} />
        {/* <Stack.Screen name="FlyerEditor" component={FlyerEditorScreen} /> */}
        <Stack.Screen name="FlyerPreview" component={FlyerPreviewScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
