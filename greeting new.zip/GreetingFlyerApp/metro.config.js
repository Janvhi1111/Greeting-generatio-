const { getDefaultConfig } = require('expo/metro-config');

module.exports = (async () => {
  const config = await getDefaultConfig(__dirname);
  const { assetExts, sourceExts } = config.resolver;

  return {
    ...config,
    resolver: {
      ...config.resolver,
      assetExts: [...assetExts, 'svg'], // Keep .svg as asset
      sourceExts: sourceExts.filter(ext => ext !== 'svg'), // Remove .svg from source
    },
  };
})();
