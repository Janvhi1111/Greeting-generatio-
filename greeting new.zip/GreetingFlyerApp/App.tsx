import React, { useEffect } from "react";
import * as Notifications from "expo-notifications";
import AppNavigator from "./src/navigation/AppNavigator";
import { deleteDatabase, initDB } from "./src/services/eventService";

export default function App() {
  useEffect(() => {
    // 1. Initialize SQLite
    //  deleteDatabase(); // 🧨 Only during dev/reset

    initDB();

    // 2. Ask for notification permissions
    const setupNotifications = async () => {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== "granted") {
        console.warn("Notification permissions not granted");
      }
    };

    setupNotifications();

    // 3. Set foreground notification behavior
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
        shouldShowBanner: true, // ✅ Required
        shouldShowList: true, // ✅ Required
      }),
    });
  }, []);

  return <AppNavigator />;
}
